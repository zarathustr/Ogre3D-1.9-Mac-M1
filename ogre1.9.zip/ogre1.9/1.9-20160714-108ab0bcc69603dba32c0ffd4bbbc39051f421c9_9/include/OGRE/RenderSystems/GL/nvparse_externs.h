#ifndef NVPARSE_EXTERNS_H
#define NVPARSE_EXTERNS_H

extern nvparse_errors errors;
extern int line_number;
extern char * myin;
#include <OgreGLPrerequisites.h>
#include <GL/glew.h>

#endif
